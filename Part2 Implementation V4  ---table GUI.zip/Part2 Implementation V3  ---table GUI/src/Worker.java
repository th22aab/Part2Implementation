public class Worker {
    private Log log;

    public Worker() {
        this.log = Log.getInstance();
    }

    public void processCustomer(Customer customer, ParcelMap parcelMap) {
        Parcel parcel = parcelMap.getParcel(customer.getParcelId());
        if (parcel != null && parcel.getStatus() != "Collected") {
            double fee = parcel.calculateFee();
            parcel.setStatus("Collected");
            log.addLog(String.format("Processed Customer: %s, Collected Parcel: %s, Fee: $%.2f",
                    customer.getName(), parcel.getId(), fee));
        } else {
            log.addLog(String.format("Customer: %s tried to collect parcel %s, but it was not found or already collected.",
                    customer.getName(), customer.getParcelId()));
        }
    }
}