import java.io.FileWriter;
import java.io.IOException;

public class Log {
    private static Log instance;
    private StringBuilder logBuffer;

    // Private constructor to enforce Singleton pattern
    private Log() {
        logBuffer = new StringBuilder();
    }

    // Singleton Instance Getter
    public static Log getInstance() {
        if (instance == null) {
            instance = new Log();
        }
        return instance;
    }

    // Add a log entry
    public void addLog(String message) {
        logBuffer.append(message).append(System.lineSeparator());
    }

    // Write logs to a file
    public void writeToFile(String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(logBuffer.toString());
            System.out.println("Log written to file: " + filename);
        } catch (IOException e) {
            System.err.println("Error writing log to file: " + e.getMessage());
        }
    }

    // Override toString for printing the log
    @Override
    public String toString() {
        return logBuffer.toString();
    }
}