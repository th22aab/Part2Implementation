import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class GUI {
    private JFrame frame;
    private JTable parcelTable;
    private JTable customerQueueTable;
    private JTextArea logTextArea;
    private QueueOfCustomers queue;
    private ParcelMap parcelMap;
    private Worker worker;





    public GUI(QueueOfCustomers queue, ParcelMap parcelMap, Worker worker) {
        this.queue = queue;
        this.parcelMap = parcelMap;
        this.worker = worker;
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Parcel Processing System");
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout(10, 10));

        // Panels for each section
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1, 2, 10, 10));
        frame.getContentPane().add(mainPanel, BorderLayout.CENTER);

        // Parcel table to show parcels to be processed
        JPanel parcelPanel = new JPanel(new BorderLayout());
        parcelPanel.setBorder(BorderFactory.createTitledBorder("Parcels To Be Processed"));
        mainPanel.add(parcelPanel);

        parcelTable = new JTable(new DefaultTableModel(new Object[]{"Parcel ID", "Weight", "Days in Depot", "Dimensions", "Status"}, 0));
        parcelPanel.add(new JScrollPane(parcelTable), BorderLayout.CENTER);

        // Customer queue table to show customers
        JPanel customerPanel = new JPanel(new BorderLayout());
        customerPanel.setBorder(BorderFactory.createTitledBorder("Customer Queue"));
        mainPanel.add(customerPanel);

        customerQueueTable = new JTable(new DefaultTableModel(new Object[]{"Sequence Number", "Name", "Parcel ID"}, 0));
        customerPanel.add(new JScrollPane(customerQueueTable), BorderLayout.CENTER);

        // Text area to show logs
        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setBorder(BorderFactory.createTitledBorder("Log"));
        frame.getContentPane().add(logPanel, BorderLayout.SOUTH);

        logTextArea = new JTextArea(5, 20);
        logTextArea.setEditable(false);
        logPanel.add(new JScrollPane(logTextArea), BorderLayout.CENTER);

        // Button panel to handle actions
        JPanel buttonPanel = new JPanel();
        frame.getContentPane().add(buttonPanel, BorderLayout.NORTH);

        JButton processButton = new JButton("Process Next Customer");
        processButton.addActionListener(e -> processNextCustomer());
        buttonPanel.add(processButton);

        JButton loadButton = new JButton("Load Data");
        loadButton.addActionListener(e -> loadData());
        buttonPanel.add(loadButton);
    }



    public void processNextCustomer() {
        if (!queue.isEmpty()) {
            Customer customer = queue.removeFirstCustomer();
            worker.processCustomer(customer, parcelMap);
            updateTables();
            logTextArea.append(Log.getInstance().toString() + "\n");
            Log.getInstance().writeToFile("log.txt");
        } else {
            JOptionPane.showMessageDialog(frame, "No more customers in the queue.");
        }
    }

    public void updateTables() {
        // Update parcel table
        DefaultTableModel parcelTableModel = (DefaultTableModel) parcelTable.getModel();
        parcelTableModel.setRowCount(0); // Clear existing data
        for (Parcel parcel : parcelMap.getParcels()) {
            if (!parcel.getStatus().equals("Collected")) {
                // Add uncollected parcels to the table
                parcelTableModel.addRow(new Object[]{
                        parcel.getId(),
                        parcel.getWeight(),
                        parcel.getDaysInDepot(),
                        parcel.getDimensions(),
                        parcel.getStatus()
                });
            }
        }

        // Update customer queue table
        DefaultTableModel customerQueueTableModel = (DefaultTableModel) customerQueueTable.getModel();
        customerQueueTableModel.setRowCount(0); // Clear existing data
        for (Customer customer : queue.getCustomers()) {
            customerQueueTableModel.addRow(new Object[]{
                    customer.getSequenceNumber(), customer.getName(), customer.getParcelId()
            });
        }
    }
    public void loadData() {
        parcelMap.readfile("Parcels.csv");
        queue.readfile("Custs.csv");
        updateTables();

    }
    public JFrame getFrame() {
        return frame;
    }
}