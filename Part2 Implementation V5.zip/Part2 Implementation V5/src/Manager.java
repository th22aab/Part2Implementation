import javax.swing.*;
import java.io.IOException;

public class Manager {

    private QueueOfCustomers queue;
    private ParcelMap parcelMap;
    private Worker worker;
    private GUI gui;

    public static void main(String[] args) {
        // Create the Manager instance and start the process
        Manager manager = new Manager();
        manager.startProcess();
    }

    public Manager() {
        // Initialize all necessary components
        queue = new QueueOfCustomers();
        parcelMap = new ParcelMap();
        worker = new Worker();

        // Create the GUI and pass necessary objects
        gui = new GUI(queue, parcelMap, worker);

        // Make the GUI visible
        SwingUtilities.invokeLater(() -> {
            gui.getFrame().setVisible(true);
        });
    }

    public void startProcess() {
        // Example: Load data from files (or simulate loading here)
        queue.readfile("Custs.csv");
        parcelMap.readfile("Parcels.csv");

        // Update the GUI with initial data
        gui.processNextCustomer();  // You can call this to refresh the tables after data loading

    }

    public void processNextCustomer() {
        if (!queue.isEmpty()) {
            Customer customer = queue.removeFirstCustomer();
            worker.processCustomer(customer, parcelMap);
            gui.processNextCustomer();  // Update the table data after processing
        } else {
            System.out.println("No more customers in the queue.");
        }
    }
}
