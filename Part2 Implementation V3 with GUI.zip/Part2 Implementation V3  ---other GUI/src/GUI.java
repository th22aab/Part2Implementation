import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GUI {
    private JFrame frame;
    private JTextArea parcelTextArea;
    private JTextArea customerQueueTextArea;
    private JTextArea logTextArea;
    private QueueOfCustomers queue;
    private ParcelMap parcelMap;
    private Worker worker;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                GUI window = new GUI();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public GUI() {
        queue = new QueueOfCustomers();
        parcelMap = new ParcelMap();
        worker = new Worker();

        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Parcel Processing System");
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout(10, 10));

        // Panels for each section
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1, 2, 10, 10));
        frame.getContentPane().add(mainPanel, BorderLayout.CENTER);

        // Panel for parcel info
        JPanel parcelPanel = new JPanel(new BorderLayout());
        parcelPanel.setBorder(BorderFactory.createTitledBorder("Parcels To Be Processed"));
        mainPanel.add(parcelPanel);

        parcelTextArea = new JTextArea(10, 30);
        parcelTextArea.setEditable(false);
        parcelPanel.add(new JScrollPane(parcelTextArea), BorderLayout.CENTER);

        // Panel for customer queue info
        JPanel customerPanel = new JPanel(new BorderLayout());
        customerPanel.setBorder(BorderFactory.createTitledBorder("Customer Queue"));
        mainPanel.add(customerPanel);

        customerQueueTextArea = new JTextArea(10, 30);
        customerQueueTextArea.setEditable(false);
        customerPanel.add(new JScrollPane(customerQueueTextArea), BorderLayout.CENTER);

        // Panel for logs
        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setBorder(BorderFactory.createTitledBorder("Log"));
        frame.getContentPane().add(logPanel, BorderLayout.SOUTH);

        logTextArea = new JTextArea(5, 20);
        logTextArea.setEditable(false);
        logPanel.add(new JScrollPane(logTextArea), BorderLayout.CENTER);

        // Button panel to handle actions
        JPanel buttonPanel = new JPanel();
        frame.getContentPane().add(buttonPanel, BorderLayout.NORTH);

        JButton processButton = new JButton("Process Next Customer");
        processButton.addActionListener(e -> processNextCustomer());
        buttonPanel.add(processButton);

        JButton loadButton = new JButton("Load Data");
        loadButton.addActionListener(e -> loadData());
        buttonPanel.add(loadButton);

    }


    public void processNextCustomer() {
        if (!queue.isEmpty()) {
            Customer customer = queue.removeFirstCustomer();
            worker.processCustomer(customer, parcelMap);
            updateTextAreas();
            logTextArea.append(Log.getInstance().toString() + "\n");
            Log.getInstance().writeToFile("log.txt");
        } else {
            JOptionPane.showMessageDialog(frame, "No more customers in the queue.");
        }
    }

    public void updateTextAreas() {
        // Update parcel text area
        StringBuilder parcelInfo = new StringBuilder();
        for (Parcel parcel : parcelMap.getParcels()) {
            if (!parcel.getStatus().equals("Collected")) {
                // Add uncollected parcels to the text area
                parcelInfo.append(String.format("Parcel ID: %s, Weight: %.2f, Days in Depot: %d, Dimensions: %s, Status: %s\n",
                        parcel.getId(), parcel.getWeight(), parcel.getDaysInDepot(), parcel.getDimensions(), parcel.getStatus()));
            }
        }
        parcelTextArea.setText(parcelInfo.toString());

        // Update customer queue text area
        StringBuilder customerInfo = new StringBuilder();
        for (Customer customer : queue.getCustomers()) {
            customerInfo.append(String.format("Seq No: %s, Name: %s, Parcel ID: %s\n",
                    customer.getSequenceNumber(), customer.getName(), customer.getParcelId()));
        }
        customerQueueTextArea.setText(customerInfo.toString());
    }

    public void loadData() {
        parcelMap.readfile("Parcels.csv");
        queue.readfile("Custs.csv");
        updateTextAreas();
    }
}
