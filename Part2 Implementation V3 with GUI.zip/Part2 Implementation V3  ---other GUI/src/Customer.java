import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Customer {
    private String sequenceNumber;
    private String Name;
    private String pacelId;

    public Customer(String sequenceNumber, String Name, String pcelId) {
        this.sequenceNumber = sequenceNumber;
        this.Name = Name;
        this.pacelId = pcelId;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getParcelId() {
        return pacelId;
    }

    public void setPacelId(String pacelId) {
        this.pacelId = pacelId;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "sequenceNumber='" + sequenceNumber + '\'' +
                ", Name='" + Name + '\'' +
                ", pacelId='" + pacelId + '\'' +
                "}\n";
    }
}
