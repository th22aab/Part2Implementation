public class Parcel {
    private String id;
    private double weight;
    private int daysInDepot;
    private String dimensions;
    private String status ;

    public Parcel(String id, double weight, int daysInDepot, String dimensions, String status) {
        this.id = id;
        this.weight = weight;
        this.daysInDepot = daysInDepot;
        this.dimensions = dimensions;
        this.status = "Uncollected";
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public String getStatus() {
        return status;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getDaysInDepot() {
        return daysInDepot;
    }

    public void setDaysInDepot(int daysInDepot) {
        this.daysInDepot = daysInDepot;
    }

    public double calculateFee() {
        String[] dimensions = this.dimensions.split("X");
        double finalDimensions = 1;
        for (String dimension : dimensions) {
            finalDimensions *= Double.parseDouble(dimension);
        }

        if (id.contains("X")){
            return weight*0.5 + daysInDepot*0.2 + finalDimensions*0.3;
        }
        else{
            return weight*0.6 + daysInDepot*0.2 + finalDimensions*0.3;
        }
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Parcel{" +
                "id='" + id + '\'' +
                ", weight=" + weight +
                ", daysInDepot=" + daysInDepot +
                ", dimensions='" + dimensions + '\'' +
                ", status='" + status + '\'' +
                "}\n";
    }
}
