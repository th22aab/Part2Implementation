import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class QueueOfCustomers {
    private ArrayList<Customer> customers;

    public QueueOfCustomers() {
        this.customers = new ArrayList<>();
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }
    public void removeCustomer(Customer customer ) {
        customers.remove(customer);
    }

    public void readfile(String filename){

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            int count = 1 ;
            while ((line = reader.readLine()) != null) {
                // Split the line by the comma (CSV delimiter)
                String[] values = line.split(",");

                if (values.length == 2) {
                    String name = values[0].trim();
                    String pacelId = values[1].trim();


                    Customer customer = new Customer(String.valueOf(count), name, pacelId);
                    customers.add(customer);
                    count++;
                }
                System.out.println(); // Move to the next line
            }
        } catch (IOException e) {
            System.err.println("Error reading the CSV file: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "QueueOfCustomers{" + customers + '}';
    }
}
