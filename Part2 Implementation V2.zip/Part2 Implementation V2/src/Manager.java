public class Manager {
    public static void main(String[] args) {
        ParcelMap parcelMap = new ParcelMap();
        QueueOfCustomers queue = new QueueOfCustomers();
        Worker worker = new Worker();
        Log log = Log.getInstance();



        parcelMap.readfile("Parcels.csv");
        queue.readfile("Custs.csv");

        System.out.println(parcelMap);
        System.out.println(queue);



        while (!queue.isEmpty()) {
            Customer currentCustomer = queue.removeFirstCustomer();
            worker.processCustomer(currentCustomer, parcelMap);
        }

        System.out.println("Log:");
        System.out.println(log);

        log.writeToFile("log.txt");

    }
}