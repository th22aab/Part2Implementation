import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ParcelMap {
    private Map<String, Parcel> parcels;

    public ParcelMap() {
        parcels = new HashMap<>();
    }

    public void addParcel(Parcel parcel) {
        parcels.put(parcel.getId(), parcel);

    }

    public Parcel getParcel(String id) {
        return parcels.get(id);
    }

    public void removeParcel(String id) {
        parcels.remove(id);
    }

    public void readfile(String filename) {

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line by the comma (CSV delimiter)
                String[] values = line.split(",");
                if (values.length == 6) {
                    String id = values[0].trim();
                    double weight = Double.parseDouble(values[1].trim());
                    int daysInDepot = Integer.parseInt(values[2].trim());
                    String dimensions = values[3].trim() + "X" + values[4].trim() + "X" + values[5].trim();

                    Parcel parcel = new Parcel(id, weight, daysInDepot, dimensions, "Uncollected");
                    parcels.put(id, parcel);
                }



                System.out.println(); // Move to the next line
            }
        } catch (IOException e) {
            System.err.println("Error reading the CSV file: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "ParcelMap{" + parcels + '}';
    }
}





